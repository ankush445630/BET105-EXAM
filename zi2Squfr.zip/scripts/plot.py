"""
Combine every per-k CSV for a given n into one boxplot.
Each box = distribution of sample means across the REPS replicates.
A dashed line at (n+1)/2 marks the true mean.
"""

import pandas as pd
import matplotlib.pyplot as plt

n = int(snakemake.wildcards.n)

# Read every input CSV, then build one list-of-arrays in increasing k order.
frames = [pd.read_csv(f) for f in snakemake.input]
df     = pd.concat(frames, ignore_index=True)

k_vals = sorted(df["k"].unique())
data   = [df.loc[df["k"] == k, "mean"].values for k in k_vals]

labels = [f"k={k}" for k in k_vals]

fig, ax = plt.subplots(figsize=(11, 6))
# `tick_labels` was renamed from `labels` in matplotlib 3.9 — fall back for older.
try:
    ax.boxplot(data, tick_labels=labels)
except TypeError:
    ax.boxplot(data, labels=labels)

true_mean = (n + 1) / 2
ax.axhline(true_mean, color="red", linestyle="--", alpha=0.6,
           label=f"True mean = {true_mean}")

ax.set_title(f"Testing Draws for {n}")
ax.set_ylabel("Mean")
ax.set_xlabel("Number of draws")
ax.legend(loc="lower right")

plt.tight_layout()
plt.savefig(snakemake.output[0], dpi=150)
