"""
Draw k integers uniformly from 1..n, take the mean, and repeat REPS times.
Writes a tidy CSV with one row per replicate: columns = k, mean.

Called by Snakemake — `snakemake` global is injected at runtime.
"""

import numpy as np
import pandas as pd

n    = int(snakemake.wildcards.n)
k    = int(snakemake.wildcards.k)
reps = int(snakemake.params.reps)

# Deterministic per-(n, k) seed so reruns reproduce the same plot.
seed = (n * 1_000_003 + k) & 0xFFFFFFFF
rng  = np.random.default_rng(seed)

# Each replicate: draw k samples from 1..n, store the sample mean.
means = rng.integers(1, n + 1, size=(reps, k)).mean(axis=1)

pd.DataFrame({"k": k, "mean": means}).to_csv(snakemake.output[0], index=False)
